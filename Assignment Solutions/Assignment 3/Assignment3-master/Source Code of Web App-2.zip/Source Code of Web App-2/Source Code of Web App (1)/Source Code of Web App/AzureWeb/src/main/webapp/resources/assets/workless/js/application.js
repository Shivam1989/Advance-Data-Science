jQuery(document).ready(function($) {

	// Responsive menu
  	$(".open").pageslide();

	// Prettyprint
	$('pre').addClass('prettyprint');

	// Uniform
	$("select, input:checkbox, input:radio, input:file").uniform();
	
});
